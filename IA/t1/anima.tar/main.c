/*
Erick Cézar Oliveira Nascimento - GRR20131334
Cauê Oliveira Gobbo Rodrigues - GRR20135775
*/

#include <stdio.h>
#include <stdlib.h>
#include "arqs.h"

row_type *solution; // Armazena as cores que são a solução
int solution_number; // Armazena o número de passos

typedef struct node_type{ // Estrutura do nó que armazena as informações necesárias
	list_type *edges; // Lista de vizinhos do nó
	int x, y, color, id;
} node_type;

typedef struct graph_type{ // Estrutura do grafo
	list_type *nodes; // Lista de nós de um grafo
} graph_type;

/* Le o grafo em um formato matricial, os nós ainda não possuem vizinhos,
mas os campos x e y marcam sua posição referente a linha e coluna em que se encontram */
void read_board(graph_type *board, int max_rows, int max_columns){
	int current_row, current_column;
	node_type *aux_node;
	board->nodes = init_list(); // inicia a lista de nós
	current_row = 0; // inicia a contagem de linhas
	current_column = 0; // inicia a contagem de colunas
	while(current_row < max_rows){ // enquanto não ler todas as linhas
		aux_node = (node_type*)malloc(sizeof(node_type)); // aloca um novo nó
		aux_node->x = current_row; // atribui a linha corrente
		aux_node->y = current_column; // atribui a coluna corrente
		aux_node->id = 0; // zera o ID
		scanf("%d", &aux_node->color); // le a cor da entrada padrão
		insert_list(board->nodes, aux_node); // insere na lista de nós
		current_column = (current_column + 1) % max_columns; // incrementa a coluna
		if(!current_column) current_row++; // incrementa a linha
	}
}

/* Cria os vizinhos com base em sua posição matricial, ou seja, o nó [l,c]
será vizinho dos nós [l+1, c], [l-1, c], [l, c+1], [l, c-1] */
void create_edges(graph_type *board){
	list_node_type *lonl, *ronl;
	node_type *lon, *ron;
	lonl = first_on_list(board->nodes); // a partir do primeiro nó do grafo
	while(!(end_list(board->nodes, lonl))){ // até o último
		lon = get_content(lonl); // pego o conteudo do nó
		lon->edges = init_list(); // inicio a lista de vizinhos
		ronl = first_on_list(board->nodes); // checo os nós do grafo novamente
		while(!(end_list(board->nodes, ronl))){ // até o último
			ron = get_content(ronl); // pego o conteúdo do nó
			if( // se ele é um vizinho matricial
			((lon->x == ron->x) && (abs(lon->y - ron->y) == 1)) ||
			((lon->y == ron->y) && (abs(lon->x - ron->x) == 1)))
				insert_list(lon->edges, ron); // insiro na minha lista de vizinhos
			ronl = next_on_list(ronl); // checo o próximo
		}
		lonl = next_on_list(lonl); // faço isso para o próximo nó
	}
}

/* Atribui IDs específicos para ser possível agrupar os nós, um bloco da mesma cor deve possuir o mesmo ID */
void recursive_set_ids(node_type *node, int *current_id, int *check, int color){
	list_node_type *walker;
	node_type *neighbor;
	if((!(node->id)) && (node->color == color)){ // se o nó não possui ID e é da mesma cor que seu vizinho
		node->id = *current_id; // recebe o mesmo ID do vizinho
		walker = first_on_list(node->edges); // desde o primeiro vizinho
		while(!(end_list(node->edges, walker))){ // até o último
			neighbor = get_content(walker); // pego o nó
			recursive_set_ids(neighbor, current_id, check, color); // faço a mesma verificação
			walker = next_on_list(walker); // vou para o próximo
		}
		*check = 1; // marco se um ID foi atribuído
	}
}

/* Controla a função de atribuição de IDs */
int set_ids(graph_type *board){
	list_node_type *walker;
	node_type *content;
	int current_id = 1, check;
	walker = first_on_list(board->nodes); // desde o primeiro nó
	while(!(end_list(board->nodes, walker))){ // até o último
		check = 0; // zera a variável de controle que o ID foi utilizado
		content = get_content(walker); // pega o conteúdo do nó
		content->x = 0; //zera a variável x (usada posteriormente)
		recursive_set_ids(content, &current_id, &check, content->color); // chama a função recursiva
		if(check) current_id++; // se eu utilizei meu ID, utilizo o próximo
		walker = next_on_list(walker); // testo o próximo
	}
	return current_id; // Retorno o ID corrente para saber quantos nós eu terei
}

/* Função que agrupa os nós conforme os IDs que eles possuem,
um conjunto de nós da mesma cor vira apenas um nó com a uniáo dos vizinhos*/
void recursive_set_neighbors(node_type *node, int id, graph_type *board, int color){
	list_node_type *walker;
	node_type *neighbor, *source = NULL, *destiny = NULL, *new_node;
	if((node->id == id) && !(node->x)){ // se o nó tem o ID que eu busco e não foi visitado (x)
		node->x = 1; // marco como visitado
		walker = first_on_list(node->edges); // pego seu primeiro vizinho
		while(!(end_list(node->edges, walker))){ // até o último
			neighbor = get_content(walker); // pego o conteúdo do nó
			recursive_set_neighbors(neighbor, id, board, color); // checo os IDs dos vizinhos
			walker = next_on_list(walker); // checo o próximo
		}
	}
	else if(!(node->color == color)){ // se meu vizinho for de cor diferente
		walker = first_on_list(board->nodes); // pego o primeiro nó do grafo
		while(!(end_list(board->nodes, walker))){ // até o último
			new_node = get_content(walker); // pego o conteúdo do nó
			if(new_node->id == id){ // se o meu nó tem o ID corrente
				new_node->color = color; // então ele recebe a cor corrente
				source = new_node; // e vira meu nó de origem
			}
			if(new_node->id == node->id) // se meu nó tem o ID de destino
				destiny = new_node; // ele virá meu nó destino
			if(source && destiny) break; // se encontrei meus nós de origem e destino eu saio
			walker = next_on_list(walker); // checo o próximo nó
		}
		insert_list(source->edges, destiny); // meu nó destino entra na lista de vizinhos do nó origem
	}
}

/* Controla a função recursiva de monta a vizinhança, à partir de um grafo sem vizinhança,
checa pelos IDs quem deve ser os vizinhos dos nós e insere eles em suas vizinahnças */
void define_neighborhood(graph_type *board, graph_type *new_board){
	list_node_type *walker;
	node_type *content;
	walker = first_on_list(board->nodes); // à partir do primeiro nó do grafo antigo
	while(!(end_list(board->nodes, walker))){ // até o último
		content = get_content(walker); // pego o conteúdo do nó
		recursive_set_neighbors(content, content->id, new_board, content->color); // defino seus vizinhos
		walker = next_on_list(walker); // chamo o próximo nó
	}
}

/* à partir do grafo montado no início, monta o grafo agrupado por cores usando os IDs atribuídos */
graph_type* organize_board(graph_type *board, int nodes_number){
	graph_type *new_board = (graph_type*)malloc(sizeof(graph_type));
	node_type *new, *content;
	list_node_type *walker;
	int i;
	new_board->nodes = init_list(); // inicia a lista de nós do novo grafo
	for(i=1; i<nodes_number; i++){ // para todos os IDs que eu atribui
		new = (node_type*)malloc(sizeof(node_type)); // aloco um novo nó
		new->edges = init_list(); // inicio a lista de vizinhos desse nó
		new->id = i; // defino o ID correspondente
		new->x = 0; // reseto a variável de controle x
		new->y = 0; // reseto a variável de controle y
		insert_list(new_board->nodes, new); // insiro na lista de nós do grafo novo
	}
	define_neighborhood(board, new_board); // defino a vizinhança dos nós
	walker = first_on_list(new_board->nodes); // desde o primeiro nó
	while(!(end_list(new_board->nodes, walker))){ //até o último
		content = get_content(walker); // pega o conteúdo do nó
		remove_duplicate(content->edges); // remove vizinhos duplicados
		walker = next_on_list(walker); // pega o próximo da fila
	}
	return new_board; // retorno o grafo criado
}

/* desalocação de nós */
void deallocate_nodes(void *p){
	node_type *aux = p;
	deallocate_list(aux->edges);
	free(aux);
}

/*desalocação de grafo */
void deallocate_board(graph_type *board){
	for_all_in_list(board->nodes, deallocate_nodes);
	deallocate_list(board->nodes);
	free(board);
}

/* marca a variável de controle x como zero */
void uncheck_visited(void *p){
	node_type *content = p;
	content->x = 0;
}

/* Dado o grafo e um nó escolhido como objetivo, simulamos a pintura com a cor desse nó e verificamos qual a soma de distâncias que o tabuleiro retorna para essa jogada */
int estimate_cost(graph_type *board, node_type *neighbor){
	int distance = 0;
	list_node_type *walker, *first = first_on_list(board->nodes);
	node_type *aux, *content_aux, *content_first = get_content(first);
	row_type *to_process = init_row(); // Iniciamos uma fila de processamento
	for_all_in_list(board->nodes, uncheck_visited); // Marcamos os nós como não visitados
	content_first->y = 0; // Definimos a distância do nó raiz como 0
	content_first->x = 1; // Marcamos o nó raiz como visitado
	enter_row(to_process, content_first); // colocamos o nó raiz na fila de processamento
	neighbor->y = 0; // Definimos a distância do nó escolhido como 0
	neighbor->x = 1; // Marcamos o nó escolhido como visitado
	enter_row(to_process, neighbor); // colocamos o nó escolhido na fila de processamento
	while(!(row_is_empty(to_process))){ // Enquanto ouver nós na fila
		aux = turn_row(to_process); // pego o primeiro nó da fila
		walker = first_on_list(aux->edges); // para o primeiro vizinho dele
		while(!(end_list(aux->edges, walker))){ // até o último
			content_aux = get_content(walker); // pego o conteúdo do nó
			if(!content_aux->x){ // se ainda não foi visitado
				content_aux->x = 1; // marco como visitado
				content_aux->y = aux->y + 1; // inserido que a distância dele é a distância de seu pai + 1
				distance += content_aux->y; // somo sua distância no total
				enter_row(to_process, content_aux); // coloco o nó na lista de processamento
			}
			walker = next_on_list(walker); // vou para o próximo vizinho
		}
	}
	return distance; // retorno a soma de distâncias resultante
}

/* Apenas junta dois nós, é utilizado quando de fato pintamos o tabuleiro, junta o nó principal com o nó escolhido */
void merge_nodes(graph_type *board, node_type *root, node_type *chosen){
	list_node_type *walker, *walker_list;
	node_type *neighbor;
	root->color = chosen->color; // raiz recebe a cor do nó escolhido
	walker = first_on_list(chosen->edges); // pego o primeiro vizinho do nó escolhido
	while(!(end_list(chosen->edges, walker))){ // até o último
		neighbor = get_content(walker); // pego o conteúdo desse vizinho
		if((!(is_on_list(neighbor->edges, root))) && (neighbor != root)) // se o nó não é a raiz ou não tem a raiz como vizinho
			insert_list(neighbor->edges, root); // insiro a raiz como vizinho deste nó
		remove_list(neighbor->edges, chosen); // removo o nó escolhido da lista de vizinhos
		walker = next_on_list(walker); // vou para o próximo vizinho
	}
	walker_list = first_on_list(chosen->edges); // para o primeiro vizinho do nó escolhido
	while(!end_list(chosen->edges, walker_list)){ // até o último
		if(!is_on_list(root->edges, get_content(walker_list))) // se não é vizinho da raiz
			insert_list(root->edges, get_content(walker_list)); // insere como vizinho da raiz
		walker_list = next_on_list(walker_list); // pega o próximo vizinho
	}
	remove_list(root->edges, root); // remove a raiz de sua própria lista de vizinhos
	deallocate_list(chosen->edges); // desaloca a lista de vizinhos do nó escolhido
	free(chosen); // desaloca o nó escolhido
	remove_list(board->nodes, chosen); // remove da lista de nós do grafo
}

/* recebe uma cor e busca por vizinhanças dessa cor, ao encontrar, pinta o tabuleiro  com a função merge_nodes */
void paint(graph_type *board, node_type *root, int color){
	list_node_type *walker, *aux;
	node_type *neighbor;
	root->color = color; // Raiz recebe cor escolhida para pintar
	walker = first_on_list(root->edges); // desde o primeiro vizinho do nó raiz
	while(!(end_list(root->edges, walker))){ // até o último
		neighbor = get_content(walker); // pego o conteúdo do vizinho
		aux = next_on_list(walker); // salvo o próximo vizinho (pois os vizinhos se alteram em merge_nodes)
		if(neighbor->color == color) // se o vizinho é da cor procurada
			merge_nodes(board, root, neighbor); // agora ele faz parte do nó raiz
		walker = aux; // devolvo o valor do próximo vizinho para walker
	}
}

void solve_board(graph_type *board){
	int current_cost, lower = 2000000, *new_color; // defino minha menor distância como "infinito" para controle
	list_node_type *walker_board, *walker_node;
	node_type *content, *neighbor, *best;
	walker_board = first_on_list(board->nodes); // pego o primeiro nó do grafo, a raiz
	content = get_content(walker_board); // pego o conteúdo da raiz
	walker_node = first_on_list(content->edges); // pego o primeiro vizinho do nó raiz
	while(!(list_is_empty(content->edges))){ // enquanto o nó raiz ainda tiver vizinhos
		while(!(end_list(content->edges, walker_node))){ // ando por todos os meus vizinhos
			neighbor = get_content(walker_node); // pego o conteúdo do vizinho
			current_cost = estimate_cost(board, neighbor); // estimo o valor corrente das distâncias
			if(current_cost <= lower){ // se o valor atual é menor que o "menor"
				lower = current_cost; // ele passa a ser o menor valor
				best = neighbor; // salvo o vizinho que retornou o menor valor
			}
			walker_node = next_on_list(walker_node); // pego o próximo vizinho
		}
		new_color = (int*)malloc(sizeof(int)); // crio uma cor
		*new_color = best->color; // essa cor tem a cor do melhor vizinho para pintar
		enter_row(solution, new_color); // coloco essa cor na minha fila de solução
		solution_number++; // incremento meu número da solução
		paint(board, content, best->color); // pinto o tabuleiro da cor escolhida
		walker_board = first_on_list(board->nodes); // pego novamente o nó raiz
		content = get_content(walker_board); // pego o conteúdo do nó raiz
		walker_node = first_on_list(content->edges); // pego o primeiro vizinho do nó raiz
	}
}


int main(){
	int max_rows, max_columns, max_colors, nodes_number, *color;
	graph_type *new_board, *board = (graph_type*)malloc(sizeof(graph_type));
	solution = init_row(); // inicio minha fila de solução qu guarda as cores que eu utilizei
	solution_number = 0; // inicio meu número de movimentos
	scanf("%d%d%d", &max_rows, &max_columns, &max_colors); // leioas informações do tabuleiro
	read_board(board, max_rows, max_columns); // leio o tabuleiro
	create_edges(board); // crio os vizinhos
	nodes_number = set_ids(board); // verifico o número de blocos de cores consecutivos
	new_board = organize_board(board, nodes_number); // organizo o grafo conforme esses blocos de cores
	deallocate_board(board); // desaloco o grafo antigo
	solve_board(new_board); // resolvo o grafo organizado
	deallocate_board(new_board); // desaloco o grafo organizado
	printf("%d\n", solution_number); // imprimo o número de passos
	while(!(row_is_empty(solution))){ // imprimo as cores que estão na fila de solução
		color = (int*)turn_row(solution);
		printf("%d ", *color);
		free(color);
	}
	deallocate_row(solution); // desaloco a fila de solução
}
