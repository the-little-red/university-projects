#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
	int i, j, x, y, cor;
	if (argc != 4){
		printf("Uso: %s [Linhas] [Colunas] [Cores]\n", argv[0]);
		return(-1);
	}
	srand(time(NULL));
	x = atoi(argv[1]);
	y = atoi(argv[2]);
	cor = atoi(argv[3]);
	printf("%d %d %d\n", x, y, cor);
	for(i=0; i<x; i++){
		for(j=0; j<y; j++){
			printf("%d ", rand()%cor+1);
		}
		printf("\n");
	}
}
