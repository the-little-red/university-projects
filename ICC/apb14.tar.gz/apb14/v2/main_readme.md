Main Page {#mainpage}
=========
Implementado por: Arianne de Paula Bortolan GRR:20140220

Scripts auxiliares para teste: bechmark (automatiza testes) e perfctr (executa os testes) e plot (faz a plotagem de graficos).
No dinf só foi possivel realizar os testes com até 4000 variáveis, após isso o tempo que o código fica executando é longo demais e o dinf mata o processo.  

*ATENÇÂO*: SSOR executa com erros, não sendo recomendado seu uso (bug de over/underflow).

*ATENÇÂO 2*: Todo o código foi comentado com //, porém o doxy não pegou os comentarios, recomendo olhar o código fonte que está comentado caso aja alguma dúvida.
