var searchData=
[
  ['k',['K',['../structDados.html#a97e2d64551c9fee4e22a543bd61f92b6',1,'Dados']]]
];
