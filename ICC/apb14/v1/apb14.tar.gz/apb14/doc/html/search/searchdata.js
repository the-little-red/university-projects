var indexSectionsWithContent =
{
  0: "m",
  1: "m",
  2: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Ficheiros",
  2: "Páginas"
};

