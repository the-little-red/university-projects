var searchData=
[
  ['file',['file',['../structDados.html#ac4bd740bc496f6b683526ebc515912a3',1,'Dados']]]
];
