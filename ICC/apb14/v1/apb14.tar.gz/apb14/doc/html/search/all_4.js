var searchData=
[
  ['fatoracao',['fatoracao',['../main_8c.html#a6f9d3877779df563d2a682495eebb860',1,'main.c']]],
  ['file',['file',['../structDados.html#ac4bd740bc496f6b683526ebc515912a3',1,'Dados']]]
];
