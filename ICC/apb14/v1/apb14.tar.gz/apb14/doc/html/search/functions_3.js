var searchData=
[
  ['generaterandoma',['generateRandomA',['../main_8c.html#af5d683468b47a073621caf72c5df0807',1,'main.c']]],
  ['generaterandomb',['generateRandomB',['../main_8c.html#acb35881774d192494096574e644133ba',1,'main.c']]],
  ['gera_5fpc_5fjacobi',['gera_pc_jacobi',['../main_8c.html#a6259b11c2188dc298e67ece8ad003a9f',1,'main.c']]],
  ['gera_5fpc_5fssor',['gera_pc_ssor',['../main_8c.html#a6d6a574c84b57b33fbe1b91534d58844',1,'main.c']]],
  ['gradiente_5fconjugado',['gradiente_conjugado',['../main_8c.html#a3858dc7767ab80de6ae5350fa095ef16',1,'main.c']]]
];
