var searchData=
[
  ['residuo',['residuo',['../structDados.html#ab5e7c8a1945fc01d8f3eb4728b57643d',1,'Dados']]]
];
