var searchData=
[
  ['e',['E',['../structDados.html#a66ad782ee96f0925b5a48e9efacd3ac3',1,'Dados']]],
  ['erro_5fresiduo',['erro_residuo',['../main_8c.html#a5346f29420b0121a77895c3f0c6e8e32',1,'main.c']]]
];
