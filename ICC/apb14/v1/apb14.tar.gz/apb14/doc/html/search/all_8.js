var searchData=
[
  ['main',['main',['../main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main.c']]],
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['main_2eh',['main.h',['../main_8h.html',1,'']]],
  ['main_5freadme_2emd',['main_readme.md',['../main__readme_8md.html',1,'']]],
  ['matriz_5fa',['matriz_A',['../structDados.html#a1b09dae7c0cb00dbc41f0b9680cd2fca',1,'Dados']]],
  ['matriz_5fatrans',['matriz_ATrans',['../structDados.html#a2862493d9bfdd5ea63565e4f8dbece4a',1,'Dados']]],
  ['matriz_5fatransb',['matriz_ATransB',['../structDados.html#aca9dafb00cae0068eb13513463f4d7bd',1,'Dados']]],
  ['matriz_5fi',['matriz_I',['../structDados.html#a54dd30005f10370a3cf41f055c803e56',1,'Dados']]],
  ['matriz_5fmulti_5fvetor',['matriz_multi_vetor',['../main_8c.html#a3959395712b0d7fd6f86c974b3f44e8c',1,'main.c']]],
  ['max_5fiteracoes',['MAX_iTERACOES',['../structDados.html#a290a97ce1f9dca6da478f6520da7e445',1,'Dados']]],
  ['mult_5fsoma_5fvetor',['mult_soma_vetor',['../main_8c.html#ae9a223522d605394f7af3030eb0d057a',1,'main.c']]],
  ['multiplica_5fmatrizes',['multiplica_matrizes',['../main_8c.html#a45fd9173a76f73fe96d65a4e798b27e2',1,'main.c']]]
];
