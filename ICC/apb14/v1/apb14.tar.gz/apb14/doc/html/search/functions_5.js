var searchData=
[
  ['main',['main',['../main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main.c']]],
  ['matriz_5fmulti_5fvetor',['matriz_multi_vetor',['../main_8c.html#a3959395712b0d7fd6f86c974b3f44e8c',1,'main.c']]],
  ['mult_5fsoma_5fvetor',['mult_soma_vetor',['../main_8c.html#ae9a223522d605394f7af3030eb0d057a',1,'main.c']]],
  ['multiplica_5fmatrizes',['multiplica_matrizes',['../main_8c.html#a45fd9173a76f73fe96d65a4e798b27e2',1,'main.c']]]
];
