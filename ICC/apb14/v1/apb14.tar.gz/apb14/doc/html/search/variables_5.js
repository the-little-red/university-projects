var searchData=
[
  ['pc',['PC',['../structDados.html#aa084afc1766c1ea7114af08fa551f09f',1,'Dados']]]
];
