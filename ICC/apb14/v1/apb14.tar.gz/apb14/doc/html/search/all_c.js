var searchData=
[
  ['tempo',['Tempo',['../structTempo.html',1,'']]],
  ['tempo_5fiter',['Tempo_iter',['../structTempo.html#a71d18d291a952250a74f9fc20c47ae4b',1,'Tempo']]],
  ['tempo_5fpc',['Tempo_pc',['../structTempo.html#a48f3e70577ff56d3fba166ac11208152',1,'Tempo']]],
  ['tempo_5fresiduo',['Tempo_residuo',['../structTempo.html#ae1724e1e10fd247ada0ffec0d7822332',1,'Tempo']]],
  ['timestamp',['timestamp',['../main_8c.html#ad1f75d4b6d05731f71dd8fe6ee54bfeb',1,'main.c']]]
];
