var searchData=
[
  ['residuo',['residuo',['../structDados.html#ab5e7c8a1945fc01d8f3eb4728b57643d',1,'Dados']]],
  ['retro_5fsubstitui',['retro_substitui',['../main_8c.html#a435f1556870da79ae6777a2f4481b97c',1,'main.c']]]
];
