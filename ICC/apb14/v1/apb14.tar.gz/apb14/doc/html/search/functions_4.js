var searchData=
[
  ['imprime_5fm',['imprime_m',['../main_8c.html#a459146638e2daf0a919b2c174146b49e',1,'main.c']]],
  ['inicializa',['inicializa',['../main_8c.html#ab5545b23e625472bef4035860201902f',1,'main.c']]],
  ['inversa',['inversa',['../main_8c.html#a4975d2f8fd13c286e9b388dc4f4de960',1,'main.c']]]
];
