var searchData=
[
  ['retro_5fsubstitui',['retro_substitui',['../main_8c.html#a435f1556870da79ae6777a2f4481b97c',1,'main.c']]]
];
