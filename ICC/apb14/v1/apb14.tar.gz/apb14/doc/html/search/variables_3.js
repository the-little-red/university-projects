var searchData=
[
  ['matriz_5fa',['matriz_A',['../structDados.html#a1b09dae7c0cb00dbc41f0b9680cd2fca',1,'Dados']]],
  ['matriz_5fatrans',['matriz_ATrans',['../structDados.html#a2862493d9bfdd5ea63565e4f8dbece4a',1,'Dados']]],
  ['matriz_5fatransb',['matriz_ATransB',['../structDados.html#aca9dafb00cae0068eb13513463f4d7bd',1,'Dados']]],
  ['matriz_5fi',['matriz_I',['../structDados.html#a54dd30005f10370a3cf41f055c803e56',1,'Dados']]],
  ['max_5fiteracoes',['MAX_iTERACOES',['../structDados.html#a290a97ce1f9dca6da478f6520da7e445',1,'Dados']]]
];
