var searchData=
[
  ['vetor_5fb',['vetor_b',['../structDados.html#a518bbbddf5f2ba5151819d904ad41a28',1,'Dados']]],
  ['vetor_5fr',['vetor_r',['../structDados.html#abcd0fa846c42efe4086071c6acb73eef',1,'Dados']]],
  ['vetor_5fx',['vetor_x',['../structDados.html#aa214d4dd621eee0028d24143438c3e94',1,'Dados']]],
  ['vetores_5fproduto',['vetores_produto',['../main_8c.html#a7440c93d54d54f251bbc4ad5c2623f77',1,'main.c']]]
];
