var searchData=
[
  ['zera_5fvetores',['zera_vetores',['../main_8c.html#ae6f353d16fe91f563a8fc366d7efa14e',1,'main.c']]]
];
