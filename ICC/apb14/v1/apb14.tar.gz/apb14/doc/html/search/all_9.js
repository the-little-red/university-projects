var searchData=
[
  ['n',['N',['../structDados.html#ae602727369f1a88076984ee5502ffa47',1,'Dados']]],
  ['norma_5feuclidiana',['norma_euclidiana',['../main_8c.html#a7744cb5c9397509adbad3507582e3e0e',1,'main.c']]]
];
