var searchData=
[
  ['fatoracao',['fatoracao',['../main_8c.html#a6f9d3877779df563d2a682495eebb860',1,'main.c']]]
];
