var searchData=
[
  ['calcula_5ferro',['calcula_erro',['../main_8c.html#a370ec02c29040bdb6625d2da07fed513',1,'main.c']]],
  ['calcula_5ftranspostam',['calcula_transpostaM',['../main_8c.html#a034deae75bc635e696235209bb83d366',1,'main.c']]],
  ['calcula_5ftranspostav',['calcula_transpostaV',['../main_8c.html#abc6a8c9be210395d102610e21a6db05f',1,'main.c']]],
  ['criterio',['criterio',['../main_8c.html#ae44bcc063641a9854211dc2166030352',1,'main.c']]]
];
